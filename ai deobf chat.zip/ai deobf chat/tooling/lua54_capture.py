import lupa.lua54 as L
rt = L.LuaRuntime(unpack_returned_tuples=True)
rt.execute(open('stubs54b.lua').read())
src = open('vm_table54.lua').read()
rt.globals()['vmsrc'] = src
rt.execute(r'''
CAP = {}
local fn0 = load(vmsrc, "vm", "t")
h = fn0()
local vyN = 0
local origVY = h.VY
h.VY = function(...)
  vyN = vyN + 1
  local args = table.pack(...)
  if vyN == 1 then
    CAP.vyT = args[8]   -- VY's T param (7th after self)
    CAP.vyargs = {}
    for i = 2, math.min(args.n, 16) do CAP.vyargs[#CAP.vyargs+1] = tostring(args[i]) end
  end
  return origVY(...)
end
local xN = 0
local origX = h.x
h.x = function(...)
  xN = xN + 1
  local args = table.pack(...)
  if xN == 1 then
    CAP.xargs = {}
    for i = 2, math.min(args.n, 16) do
      local v = args[i]
      if type(v)=='userdata' or (type(v)=='table' and v.n) then v = 'BUF#' .. tostring(v):match('0x%x+') end
      CAP.xargs[#CAP.xargs+1] = tostring(v) .. ':' .. type(v)
    end
    CAP.outbuf = args[12] -- guess: the buffer written to
    error('abort-after-first-decrypt', 0)
  end
  return origX(...)
end
''')
try:
    rt.eval('tostring(h:WA()())')
except Exception as e:
    pass
cap = rt.globals()['CAP']
print('VY#1 args:', cap['vyargs'])
print('x#1 args:', cap['xargs'])
print('vyT type:', type(cap['vyT']))
