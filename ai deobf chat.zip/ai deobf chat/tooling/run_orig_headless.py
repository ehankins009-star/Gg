import lupa.lua54 as L
rt = L.LuaRuntime(unpack_returned_tuples=True)
stubs = open('stubs54.lua').read()
src = open('v15.1 headless.lua').read()
code = '''
local stubs, src = ...
local g, err = load(stubs .. src, "origchunk", "t")
if not g then return false, "LOADFAIL: " .. tostring(err) end
local steps = 0
local ok, e = xpcall(g, function(t) return debug.traceback(tostring(t), 2) .. " | steps=" .. steps end, function() steps = steps + 1 return steps < 3000000 end)
return ok, e
'''
f = rt.eval('function(...) ' + code + ' end')
ok, res = f(stubs, src)
print('ok:', ok)
print(str(res)[:2000])
