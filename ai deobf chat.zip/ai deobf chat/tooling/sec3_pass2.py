import re
lines = open('section3_clean.lua').read().splitlines()
out = []
for l in lines:
    s = l.strip()
    # turn raw import comments back into code lines with GAP markers
    m = re.match(r'-- import slot imp(\d+) access \(raw\): (r\w+ = l\[\d+\]\[l\[\d+\]\](\[[^\]]+\])?) -- GAP$', s)
    if m:
        n_, expr = m.group(1), m.group(2)
        expr = expr.replace('l[7][l[6]]', f'IMP{n_}')
        out.append(f'{expr} -- GAP: import slot {n_}, its global name was not captured by this run')
        continue
    m = re.match(r'-- import slot imp(\d+) access \(raw\): (l\[\d+\]\[l\[\d+\]\](\[[^\]]+\])?) = (.*) -- GAP$', s)
    if m:
        n_, lhs, rhs = m.group(1), m.group(2), m.group(4)
        lhs = lhs.replace('l[7][l[6]]', f'IMP{n_}')
        out.append(f'{lhs} = {rhs} -- GAP: import slot {n_}, its global name was not captured by this run')
        continue
    out.append(l)
# add stub labels for gotos whose target never appears
targets = set()
for l in out:
    s = l.strip()
    m = re.fullmatch(r'goto (L\d+)', s)
    if m: targets.add(m.group(1))
have = set(l.strip().strip(':') for l in out if re.fullmatch(r'::L\d+::', l.strip()))
missing = sorted(targets - have)
tail = []
if missing:
    tail.append('')
    for t in missing:
        tail.append(f'::{t}:: -- branch target never executed in this run; its ops are not in the trace')
out = out + tail
open('section3_clean.lua', 'w').write('\n'.join(out) + '\n')
print('missing targets:', missing)
print('lines', len(out))
