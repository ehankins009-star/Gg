import lupa.lua54 as L
rt = L.LuaRuntime(unpack_returned_tuples=True)
src = open('stubs54b.lua').read()
src = src.replace('local function get(b,i) if i==nil then return 0 end return b.d[i+1] or 0 end',
 'local function get(b,i) if i==nil then return 0 end return b.d[i+1] or 0 end\nREAD_LOG = READ_LOG or {}')
src = src.replace('function buffer.readu8(b,i) return get(b,i) end',
 'function buffer.readu8(b,i) local v=get(b,i) if #READ_LOG<200000 then READ_LOG[#READ_LOG+1]={op="u8",off=i,val=v,n=b.n} end return v end')
src = src.replace('function buffer.readu32(b,i) return get(b,i)+get(b,i+1)*256+get(b,i+2)*65536+get(b,i+3)*16777216 end',
 'function buffer.readu32(b,i) local r=get(b,i)+get(b,i+1)*256+get(b,i+2)*65536+get(b,i+3)*16777216 if #READ_LOG<200000 then READ_LOG[#READ_LOG+1]={op="u32",off=i,val=r,n=b.n} end return r end')
rt.execute(src)
rt.globals()['vmsrc'] = open('vm_table54.lua').read()
rt.execute(r'''
local fn0 = load(vmsrc, "vm", "t")
h = fn0()
pcall(function() h:WA()() end)
local f = io.open('boot_reads_all.txt','w')
for i, e in ipairs(READ_LOG) do
  f:write(e.op..' '..e.off..' '..e.val..' '..e.n..'\n')
end
f:close()
print('logged', #READ_LOG)
''')
