import re
src = open('main_clean.lua').read().splitlines()
out = []
pend_mach = False
i = 0
n = len(src)
while i < n:
    l = src[i].rstrip()
    s = l.strip()
    nxt = src[i+1].strip() if i+1 < n else ''
    # VM machinery: import materialization pair
    if s == 't, M, h = U[l], U[l + 1], U[l + 2]' and nxt.startswith('U[l] = t(M, h)'):
        out.append('-- [import slot materialization (VM machinery) collapsed]')
        i += 2
        continue
    if s == 'U[l] = t(M, h)':
        out.append('-- [import slot materialization (VM machinery) collapsed]')
        i += 1
        continue
    if re.fullmatch(r'c,o=\d+,\d+\+1;break', s):
        out.append('-- [block switch to another chunk (VM machinery) collapsed]')
        i += 1
        continue
    if s == 'd[o] = 68':
        out.append('-- [VM dispatch write collapsed]')
        i += 1
        continue
    if s == '_[r] = ""':
        i += 1
        continue
    if re.fullmatch(r'o \+= 1|o\+=1', s):
        i += 1
        continue
    # standalone break from VM dispatch -> collapse
    if s == 'break':
        out.append('-- [VM dispatch break collapsed]')
        i += 1
        continue
    # un-mangle readable raw line
    if s.startswith('if IthenforBinV'):
        s2 = s.replace('IthenforBinV', 'I then for B in V').replace('nildo', ' nil do').replace('end;end;end;end', 'end end end end')
        s2 = s2.replace('ifIthen', 'if I then ').replace('localW=', 'local W = ').replace('W[7]=W;W[3]=U[B];W[6]=3;I[B]=nil;', 'W[7] = W; W[3] = U[B]; W[6] = 3; I[B] = nil;')
        s2 = s2.replace('ifWthen', 'if W then ').replace(';return', '; return')
        out.append(s2)
        i += 1
        continue
    # compound line with ;o+=1 suffix -> strip
    if ';o+=1' in s:
        s = s.replace(';o+=1', '')
    # markers -> GAP form
    s = re.sub(r'_\[(\d+)\]', r'GAP\1 -- GAP: global at slot \1, name not captured by this run', s)
    s = re.sub(r'T\[(\d+)\]\?', r'GAPstr\1 -- GAP: string constant not recovered', s)
    s = re.sub(r'm\[(\d+)\]\?', r'GAPc\1 -- GAP: constant not recovered', s)
    s = re.sub(r'T\[(\d+)\]\?', '', s)
    # import read: l = impN ; rX = l[7][l[6]]...
    if re.fullmatch(r'l = imp(\d+)', s):
        impn = s.split('=')[1].strip()
        # consume following line(s) that use l
        j = i + 1
        used = ''
        while j < n and 'l[' in src[j]:
            used = src[j].strip()
            j += 1
        if used:
            m = re.match(r'(r\w+|l\[\d+\]\[l\[\d+\]\]\[\w+\])\s*=\s*l\[(\d+)\]\[l\[(\d+)\]\](\[[^\]]+\])?\s*=\s*(.*)$', used)
            m2 = re.match(r'(r\w+)\s*=\s*l\[(\d+)\]\[l\[(\d+)\]\](\[[^\]]+\])?\s*=\s*(.*)$', used)
            mm = m2 or m
            if mm:
                lhs, tail = mm.group(1), mm.group(4) or ''
                out.append(f'{lhs} = IMP{impn}{tail} -- GAP: import slot {impn}, its global name was not captured by this run')
            else:
                out.append(f'-- import slot {impn} access (raw): {used} -- GAP')
            i = j
            continue
    # trivial goto followed by its own label -> drop goto, keep label
    if re.fullmatch(r'goto (L\d+)', s):
        tgt = s.split()[1]
        if nxt == f'::{tgt}::':
            i += 1
            continue
    out.append(s)
    i += 1
# merge adjacent duplicate labels
final = []
for l in out:
    if final and re.fullmatch(r'::L\d+::', l.strip()) and final[-1].strip() == l.strip():
        continue
    final.append(l)
open('section3_clean.lua', 'w').write('\n'.join(final) + '\n')
gotos = sum(1 for l in final if re.fullmatch(r'goto L\d+', l.strip()))
labels = sum(1 for l in final if re.fullmatch(r'::L\d+::', l.strip()))
print('lines', len(final), 'gotos', gotos, 'labels', labels)
print('GAPs', sum(1 for l in final if 'GAP' in l and '--' in l))
