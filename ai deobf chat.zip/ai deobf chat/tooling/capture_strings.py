import lupa.lua54 as L
rt = L.LuaRuntime(unpack_returned_tuples=True)
stubs = open('stubs54.lua').read()
src = open('vm_table54.lua').read()
harness = rt.eval(r'''
function(pre, src)
  local out = io.open("strings_dump.txt", "w")
  local g = load(pre .. src, "vmchunk")
  local ok, T = pcall(g)
  if not ok then return false, T end
  local wrap = function(name, f)
    return function(h, ...)
      local rs = {f(h, ...)}
      if name == "tostring" and type(rs[1]) == "string" then
        out:write("=== tostring len=" .. #rs[1] .. " ===\n")
        out:write(rs[1])
        out:write("\n=== end ===\n")
        out:flush()
      end
      return unpack(rs)
    end
  end
  T[6] = wrap("tostring", T[6])
  local steps = 0
  local ok2, err = xpcall(function() return T:WA() end, function(e)
    return debug.traceback(tostring(e), 2) .. " | steps=" .. steps
  end)
  out:write("END ok2=" .. tostring(ok2) .. " err=" .. tostring(err):sub(1,200) .. "\n")
  out:close()
  return ok2, tostring(err):sub(1,300)
end
''')
ok, res = harness(stubs, src)
print('run:', ok, str(res)[:200])
